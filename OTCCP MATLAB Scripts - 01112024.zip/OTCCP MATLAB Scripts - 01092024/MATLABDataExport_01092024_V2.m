function MATLABDataExport_01092024_V2(r_dir, root, type, progress)

clc
close all
savepath
warning('off','MATLAB:table:ModifiedVarnames')

progressbar('MainScript', root, 'Exporting', '', '')
progressbar(progress, 0.67, 0, 0, 0) 

workspace_dir = [r_dir 'MATLAB Data'];

if isequal(root, '')
    cd(workspace_dir)
    directory_instance = dir('*_Workspace.mat');
    file_names = string({directory_instance.name});
    
    wrkspace_str = file_names(contains(file_names, "_Workspace.mat"));
    tempsplit = split(wrkspace_str, '_');
    root = tempsplit(1);
end
workspace_filename = strcat(root, '_Workspace.mat');

oldcd = cd(workspace_dir);
M = load(workspace_filename);

%~~PART 6A: EXPORTING MAIN DATA TO EXCEL~~
%Main Data Exportation
progressbar('MainScript', char(root), 'Exporting', 'Classification Data Exportation', '')
progressbar(progress, 0.67, .1, 0, 0); cd(oldcd); cancelcheck; cd(workspace_dir); 


mkdir('Classification Results')
cd(workspace_dir); 
cellline_classdataexport(M.X, M.X_labels, M.T_labels, M.param_labels, M.objectID, M.celllines, ...
    M.forestCVErri, M.forestCVErr_dist, M.imp, M.forestCVScore, 0, 'Classification Results/AllParam');
progressbar([], [], [], .2, 0); cd(oldcd); cancelcheck; cd(workspace_dir); 
cellline_classdataexport(M.X_opg, M.X_labels, M.T_labels, M.param_labels_opg, M.objectID, M.celllines, ...
    M.forestCVErri_opg, M.forestCVErr_dist_opg, M.imp_opg, M.forestCVScore_opg, 0, 'Classification Results/OPG');
progressbar([], [], [], .35, 0); cd(oldcd); cancelcheck; cd(workspace_dir); 
cellline_classdataexport(M.X_npg, M.X_labels, M.T_labels, M.param_labels_npg, M.objectID, M.celllines, ...
    M.forestCVErri_npg, M.forestCVErr_dist_npg, M.imp_npg, M.forestCVScore_npg, 0, 'Classification Results/NPG');
progressbar([], [], [], .5, 0); cd(oldcd); cancelcheck; cd(workspace_dir); 
cellline_classdataexport(M.X_dpg, M.X_labels, M.T_labels, M.param_labels_dpg, M.objectID, M.celllines, ...
    M.forestCVErri_dpg, M.forestCVErr_dist_dpg,  M.imp_dpg, M.forestCVScore_dpg, 0, 'Classification Results/DPG');
progressbar([], [], [], .65, 0); cd(oldcd); cancelcheck; cd(workspace_dir); 
cellline_classdataexport(M.X_opgnpg, M.X_labels, M.T_labels, M.param_labels_opgnpg, M.objectID, M.celllines, ...
    M.forestCVErri_opgnpg,  M.forestCVErr_dist_opgnpg, M.imp_opgnpg, M.forestCVScore_opgnpg, 0, 'Classification Results/ONPG');
progressbar([], [], [], .8, 0); cd(oldcd); cancelcheck; cd(workspace_dir);   
cellline_classdataexport(M.X_opgdpg, M.X_labels, M.T_labels, M.param_labels_opgdpg, M.objectID, M.celllines, ...
    M.forestCVErri_opgdpg, M.forestCVErr_dist_opgdpg, M.imp_opgdpg, M.forestCVScore_opgdpg, 0, 'Classification Results/ODPG');
progressbar([], [], [], .95, 0); cd(oldcd); cancelcheck; cd(workspace_dir); 
cellline_classdataexport(M.X_npgdpg, M.X_labels, M.T_labels, M.param_labels_npgdpg, M.objectID, M.celllines, ...
    M.forestCVErri_npgdpg, M.forestCVErr_dist_npgdpg, M.imp_npgdpg, M.forestCVScore_npgdpg, 0, 'Classification Results/NDPG');
cd ../

progressbar('MainScript', char(root), 'Exporting', 'Dataset Exportation', '')
progressbar(progress, 0.67, .8, 0, 0); cd(oldcd); cancelcheck; cd(workspace_dir); 
cellline_datasetexport(M.X, M.X_labels, M.T_labels, M.param_labels, M.objectID, M.celllines, ...
    M.forestCVErri, M.forestCVErr_dist, M.imp, M.forestCVScore, M.cell_list, M.cellX_labels, 'Datasets');

progressbar('MainScript', char(root), 'Exporting', 'Error Data', '')
progressbar(progress, 0.67, .95, 0, 0); cd(oldcd); cancelcheck; cd(workspace_dir); 
numfile = append(num2str(size(M.errorfile_list, 1)), "/", num2str(size(M.cell_list, 1)), " Files Excluded");
if ~isempty(M.errorfile_list)
    errorT = cell2table(cellstr([numfile ""; M.errorfile_list]));
else
    errorT = cell2table(cellstr([numfile ""]));
end
    errorT.Properties.VariableNames = cellstr(['File' "Reasons for Removal"]);
    writetable(errorT, 'RemovedFileInformation.csv')

progressbar(1)

%cellline_dataexport: exporting desired data to an outside Excel form for further analysis.
function cellline_classdataexport(X, X_labels, T_labels, param_labels, objectID, celllines, ...
    forestCVErri, forestCVErri_alt, imp, forestCVScore, cellline_auc , filename)
    
    progressbar([], [], [], [], 0);
    mkdir(filename)
    cd(filename)
    
    progressbar([], [], [], [], .4); 
    T2 = cell2table([num2cell([1:10].') num2cell((1-forestCVErri)*100)]);
    T2.Properties.VariableNames = cellstr(['kFold' "Accuracy"]);
    writetable(T2, 'kFoldAccuracy.csv')

    progressbar([], [], [], [], .45); 
    T2 = cell2table([num2cell([1:20].') num2cell((1-forestCVErri_alt)*100)]);
    T2.Properties.VariableNames = cellstr(['kFold' "Accuracy"]);
    writetable(T2, 'AltkFoldAccuracy.csv')
    
    progressbar([], [], [], [], .5); 
    T3 = cell2table([cellstr(param_labels.') num2cell(imp.') num2cell(normalize(imp, 'range').')]);
    T3.Properties.VariableNames = cellstr(['Parameter' "Relative Predictor Importance" "Normalized Predictor Importance"]);
    writetable(T3, 'PredictorImp.csv')
    
    cd ../
    
end

function cellline_datasetexport(X, X_labels, T_labels, param_labels, objectID, celllines, ...
    forestCVErri, forestCVErri_alt, imp, forestCVScore, cell_list , cellX_labels, filename)
    
    progressbar([], [], [], [], 0);
    mkdir(filename)
    cd(filename)

    progressbar([], [], [], [], .2);
    if contains(type, "Live")
        T1 = cell2table([cellstr(X_labels) num2cell(T_labels) num2cell(objectID) num2cell(X)]);
        T1.Properties.VariableNames = cellstr(['Cellline' 'Timepoint' 'Object ID #' param_labels]);
    else
        T1 = cell2table([cellstr(X_labels) num2cell(objectID) num2cell(X)]);
        T1.Properties.VariableNames = cellstr(['Cellline' 'Object ID #' param_labels]);
    end
    writetable(T1, 'Full Dataset.csv')
    
    for i = 1:length(celllines)
        mkdir(append(celllines(i), ' Cells'))
        cd(append(celllines(i), ' Cells'))

        current_cell_list = cell_list(contains(cell_list, append(celllines(i), ' Cell')));
        for j = 1:length(current_cell_list)
            cell_idx = matches(cellX_labels, current_cell_list(j));

            if contains(type, "Live")
                T2 = cell2table([cellstr(X_labels(cell_idx,:)) num2cell(T_labels(cell_idx,:)) num2cell(objectID(cell_idx,:)) num2cell(X(cell_idx,:))]);
                T2.Properties.VariableNames = cellstr(['Cellline' 'Timepoint' 'Object ID #' param_labels]);
            else
                T2 = cell2table([cellstr(X_labels(cell_idx,:)) num2cell(objectID(cell_idx,:)) num2cell(X(cell_idx,:))]);
                T2.Properties.VariableNames = cellstr(['Cellline' 'Object ID #' param_labels]);
            end
            writetable(T2, append(current_cell_list(j), '.csv'))
        end
        cd ../
    end
    cd ../
  end
end
