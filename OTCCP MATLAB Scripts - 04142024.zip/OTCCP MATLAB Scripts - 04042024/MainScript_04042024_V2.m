clear
clc
close all
savepath
warning('off','MATLAB:table:ModifiedVarnames') 
global canceled

cancelcheck
script_dir = cd;
celllines_color = ''; 
progressbar('MainScript', '', '', '', '')

%UI Runs
%dialog box code running
[celllines, dir, root, mode] = DatasetDirSelection(script_dir);

CompleteRFScript(celllines_color, celllines, dir, root, script_dir, mode, 0.15, [])

function [celllines, direc, root, mode] = DatasetDirSelection(script_dir)
        %Import App Information
        AppData = load('UIInputValues.mat');
        delete UIInputValues.mat

        imp_dir = AppData.imp_dir;
        exp_dir = AppData.exp_dir;
        root = AppData.root_name;
        mode = AppData.mode;
        
        % DEBUG
        %imp_dir = 'C:\Users\jagol\Downloads\OTCCP_10072023-main\OTCCP_10072023-main\OTCCP MATLAB Scripts - 04042024\TestFiles\Importation Direct';
        %exp_dir = 'C:\Users\jagol\Downloads\OTCCP_10072023-main\OTCCP_10072023-main\OTCCP MATLAB Scripts - 04042024\TestFiles\Export Direct';
        %root = 'Test';
        %mode = AppData.mode;

        mkdir(strcat(exp_dir, '\IMARIS Data'))
        mkdir(strcat(exp_dir, '\MATLAB Data'))
        mkdir(strcat(exp_dir, '\Figures'))
        cd(imp_dir)

        files = dir('**/*.xls'); %structure containing information on all the files

        %Extract CL information from filenames
        file_names = string({files.name});
        CL_list = [];
        for i = 1:length(file_names)
                temp = file_names(i);
                tempsplit = split(temp, [" ", '-', '_', '~']);
                tempCL = tempsplit(1);
                CL_list = [CL_list tempCL];
        end
        celllines = string(unique(CL_list));

        if ~isequal(mode, 'exportonly')
            for j = 1:length(files)
                cd(imp_dir)
                currentfile = files(j);

                %determine CL
                filename_split = split(currentfile.name, [" ", '-', '_', '~']);
                CL = filename_split{1};
                
                %determine Cell #
                cellnum_str = regexpi(currentfile.name, 'cell([^\d]*)?\d*', 'match');
                cellnum_str = regexprep(string(cellnum_str),'[^0-9]',''); %remove special characters that may screw up the reading process
                cellnum = sscanf(string(cellnum_str), '%f');

                %determine subfolder phrase
                subdirec = erase(currentfile.folder, append(imp_dir));
                subdirec_split = split(subdirec, '\');
                subfolder_part = '';
                for k = 1:length(subdirec_split)
                    subfolder_part = append(subfolder_part, subdirec_split{k});
                    if ~(k == length(subdirec_split))
                        subfolder_part = append(subfolder_part, '_');
                    end
                end

                %craft new filename
                newname = append(CL, ' cell', string(cellnum), ' ', subfolder_part, '.xls');
                
                %copy file in question
                cd(currentfile.folder)
                copyfile(currentfile.name, strcat(exp_dir, '\IMARIS Data'));
                
                %rename the file accordingly
                cd(strcat(exp_dir, '\IMARIS Data'))
                movefile(currentfile.name, newname);
            end
        end

        cd(script_dir)
        save("ImpWrkspace.mat")
        direc = append(exp_dir,'\');
end

function CompleteRFScript(celllines_color, celllines, dir, root, script_dir, specialcase, progress, tp, type)
    import = 1; rf = 1; export = 1; pool = 0;
    if contains(specialcase, 'noimport')
        import = 0;
    elseif contains(specialcase, 'exportonly')
        import = 0; rf = 0;
    elseif contains(specialcase, 'importonly')
        rf = 0; export = 0;
    end

    if contains(specialcase, 'Live')
        type = 'Live';
        if contains(specialcase, 'pool')
            pool = 1;
        end
        if contains(specialcase, 'nonpool')
            pool = 0;
        end
    elseif contains(specialcase, 'Track')
        type = 'Track';
    else
        type = 'Fixed';
    end

    progressbar('MainScript', root, 'Importing', '', '')
   
    if (import == 1)
        IMARISDataImport_04042024_V2(celllines_color, celllines, dir, root, type, tp, pool, progress); cd(script_dir); 
    end

    progressbar('MainScript', root, 'Classification', '', '')
    
    if (rf == 1)
        RandomForest_04042024_V2(celllines_color, celllines, dir, root, progress); cd(script_dir);
    end

    progressbar('MainScript', root, 'Exporting', '', '')
    if (export == 1)
        MATLABDataExport_04042024_V2(dir, root, type, progress); cd(script_dir);
    end
    
end
